"""webyolo-agent: Model Export of a YOLOv26 best.pt to ONNX and a TensorRT engine for this PC's GPU (used by the webyolov26 page)"""
__version__ = "0.3.0"
