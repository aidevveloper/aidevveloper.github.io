"""webyolo-export: the same Model Export as the web page, from the command line (no website, no agent).

    python export.py --weights best.pt                       # -> exported/best.onnx, best.engine, names.json, info.json, run.py, zip
    python export.py --weights best.pt --imgsz 960 --fp32 --out my_model
    webyolo-export --weights best.pt                         # same, after `pip install .`
    python export.py --info                                  # only show this PC's GPU / TensorRT / PyTorch
"""
import argparse
import json
import os
import sys


def main():
    ap = argparse.ArgumentParser(prog="webyolo-export",
                                 description="YOLOv26 best.pt -> ONNX + TensorRT engine for this PC's GPU (checked against the .pt)")
    ap.add_argument("--weights", help="the .pt checkpoint (trained with the YOLOv26-pt repo)")
    ap.add_argument("--imgsz", type=int, default=640, help="input size, multiple of 32 (default 640)")
    ap.add_argument("--fp32", action="store_true", help="FP32 engine (default FP16)")
    ap.add_argument("--out", default="exported", help="output folder (default ./exported)")
    ap.add_argument("--info", action="store_true", help="only print this PC's GPU and library versions")
    a = ap.parse_args()

    from .server import gpu_info
    g = gpu_info()
    print(f"GPU       {g.get('name', g.get('error', '?'))}  (compute {g.get('compute_capability', '?')}, "
          f"driver {g.get('driver', '?')}, CUDA {g.get('cuda_driver', '?')})")
    print(f"TensorRT  {g.get('tensorrt') or 'NOT INSTALLED (pip install tensorrt)'}")
    print(f"PyTorch   {g.get('torch') or 'NOT INSTALLED'}  (CUDA: {g.get('torch_cuda')})")
    print(f"onnx {g.get('onnx')}, onnxruntime {g.get('onnxruntime')}")
    if a.info:
        return
    if not a.weights:
        ap.error("--weights is required")
    if not os.path.isfile(a.weights):
        sys.exit(f"not found: {a.weights}")
    if a.imgsz % 32 or not 160 <= a.imgsz <= 1920:
        sys.exit("--imgsz must be a multiple of 32 between 160 and 1920")
    if not g.get("tensorrt"):
        sys.exit("TensorRT is needed for the engine: pip install tensorrt")

    from .convert import ConvertError, convert
    try:
        r = convert(a.weights, a.out, a.imgsz, not a.fp32, log=lambda m: print("  " + m), gpu=g)
    except ConvertError as e:
        sys.exit(f"ERROR: {e}")
    print("\ncheck against the .pt (detections with score >= 0.25 on the sample image):")
    for k, m in r["verify"].items():
        print(f"  {k:7} pt {m['ref']} / model {m['out']}, matched {m['matched']}, box diff {m['box_px']} px, "
              f"score diff {m['score']}  -> {'SAME' if m['ok'] else 'DIFFERS'}" + (f", {m['ms']} ms" if m.get("ms") else ""))
    print(f"\nfiles in {os.path.abspath(a.out)}:")
    for f in r["files"]:
        print("  " + f)
    print(f"\nrun it:  cd {a.out} && python run.py --model {os.path.splitext(os.path.basename(a.weights))[0]}.engine --source image.jpg")


if __name__ == "__main__":
    main()
