"""webyolo-agent: local Model Export for https://aidevveloper.github.io/webyolov26/export.html

Listens on 127.0.0.1 only (default port 17860). The web page sends best.pt here; the agent exports it on this PC's GPU
(PyTorch -> ONNX -> TensorRT) and the page downloads the results. Nothing goes to any other server.
Only the web page's origin (and local pages) may use it: a .pt file can run code when it is loaded, so other
websites must never be able to send one.

    webyolo-agent                 # start, then open the web page
    webyolo-agent --port 17861
"""
import argparse
import json
import os
import re
import shutil
import subprocess
import tempfile
import threading
import time
import traceback
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

from . import __version__

ORIGINS = {"https://aidevveloper.github.io"}
LOCAL_ORIGIN = re.compile(r"^http://(localhost|127\.0\.0\.1)(:\d+)?$")
MAX_UPLOAD = 2 << 30
WORK = os.path.join(os.path.expanduser("~"), ".webyolo-agent", "jobs")
JOBS = {}
GPU_LOCK = threading.Lock()


def gpu_info():
    info = {"agent": __version__}
    try:
        q = subprocess.run(["nvidia-smi", "--query-gpu=name,compute_cap,driver_version,memory.total",
                            "--format=csv,noheader,nounits"], capture_output=True, text=True, timeout=10)
        row = [c.strip() for c in q.stdout.strip().splitlines()[0].split(",")]
        info.update(name=row[0], compute_capability=row[1], driver=row[2], memory_mb=int(float(row[3])))
        v = subprocess.run(["nvidia-smi"], capture_output=True, text=True, timeout=10).stdout
        m = re.search(r"CUDA Version:\s*([\d.]+)", v)
        info["cuda_driver"] = m.group(1) if m else None
    except Exception as e:
        info["error"] = f"nvidia-smi failed: {e}"
    for mod in ("torch", "tensorrt", "onnx", "onnxruntime"):
        try:
            info[mod] = __import__(mod).__version__
        except Exception:
            info[mod] = None
    try:
        import torch
        info["torch_cuda"] = bool(torch.cuda.is_available())
    except Exception:
        info["torch_cuda"] = False
    return info


class Job:
    def __init__(self, name):
        self.id = uuid.uuid4().hex[:12]
        self.dir = os.path.join(WORK, self.id)
        os.makedirs(self.dir)
        self.name = name
        self.state, self.progress, self.log, self.result, self.error = "queued", 0.0, [], None, None
        self.created = time.time()

    def add(self, msg):
        self.log.append(time.strftime("%H:%M:%S ") + str(msg))

    def view(self):
        return {"id": self.id, "state": self.state, "progress": round(self.progress, 3), "log": self.log[-200:],
                "result": self.result, "error": self.error}


def run_job(job, pt, size, fp16, gpu):
    from .convert import ConvertError, convert
    with GPU_LOCK:
        job.state = "running"
        try:
            job.result = convert(pt, os.path.join(job.dir, "out"), size, fp16, job.add,
                                 lambda p: setattr(job, "progress", p), gpu)
            job.state = "done"
        except ConvertError as e:
            job.error, job.state = str(e), "error"; job.add(f"ERROR: {e}")
        except Exception as e:
            job.error, job.state = f"{type(e).__name__}: {e}", "error"
            job.add("ERROR: " + traceback.format_exc())
        finally:
            try:
                os.remove(pt)                      # the uploaded checkpoint is not kept
            except OSError:
                pass


class Handler(BaseHTTPRequestHandler):
    server_version = f"webyolo-agent/{__version__}"

    def log_message(self, fmt, *args):
        if not self.path.startswith(("/jobs/", "/info")) or "POST" in fmt % args:
            print(time.strftime("%H:%M:%S"), fmt % args, flush=True)

    def origin_ok(self):
        o = self.headers.get("Origin")
        return o is None or o in ORIGINS or bool(LOCAL_ORIGIN.match(o))

    def cors(self):
        o = self.headers.get("Origin")
        if o and (o in ORIGINS or LOCAL_ORIGIN.match(o)):
            self.send_header("Access-Control-Allow-Origin", o)
            self.send_header("Vary", "Origin")
            self.send_header("Access-Control-Allow-Private-Network", "true")
            self.send_header("Access-Control-Expose-Headers", "Content-Disposition")

    def reply(self, code, body, ctype="application/json"):
        data = json.dumps(body).encode() if ctype == "application/json" else body
        self.send_response(code)
        self.cors()
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def do_OPTIONS(self):
        if not self.origin_ok():
            return self.reply(403, {"error": "origin not allowed"})
        self.send_response(204)
        self.cors()
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Max-Age", "600")
        self.end_headers()

    def do_GET(self):
        if not self.origin_ok():
            return self.reply(403, {"error": "origin not allowed"})
        u = urlparse(self.path)
        parts = [p for p in u.path.split("/") if p]
        if parts == ["info"]:
            return self.reply(200, self.server.gpu)
        if len(parts) == 2 and parts[0] == "jobs" and parts[1] in JOBS:
            return self.reply(200, JOBS[parts[1]].view())
        if len(parts) == 4 and parts[0] == "jobs" and parts[2] == "files" and parts[1] in JOBS:
            job = JOBS[parts[1]]
            if job.result and parts[3] in job.result["files"]:
                path = os.path.join(job.dir, "out", parts[3])
                self.send_response(200)
                self.cors()
                self.send_header("Content-Type", "application/octet-stream")
                self.send_header("Content-Length", str(os.path.getsize(path)))
                self.send_header("Content-Disposition", f'attachment; filename="{parts[3]}"')
                self.end_headers()
                with open(path, "rb") as f:
                    shutil.copyfileobj(f, self.wfile)
                return
        return self.reply(404, {"error": "not found"})

    def do_POST(self):
        if not self.origin_ok():
            return self.reply(403, {"error": "origin not allowed"})
        u = urlparse(self.path)
        if u.path not in ("/export", "/convert"):            # /convert: agent 0.1-0.2 pages
            return self.reply(404, {"error": "not found"})
        q = {k: v[0] for k, v in parse_qs(u.query).items()}
        n = int(self.headers.get("Content-Length") or 0)
        if n <= 0 or n > MAX_UPLOAD:
            return self.reply(400, {"error": "send the .pt file as the request body (max 2 GB)"})
        size = int(q.get("imgsz", 640))
        if size % 32 or not 160 <= size <= 1920:
            return self.reply(400, {"error": "imgsz must be a multiple of 32 between 160 and 1920"})
        name = os.path.basename(q.get("name", "best.pt")) or "best.pt"
        name = re.sub(r"[^\w.\-]", "_", name)
        if not name.endswith(".pt"):
            name += ".pt"
        job = Job(name)
        pt = os.path.join(job.dir, name)
        with open(pt, "wb") as f:
            left = n
            while left:
                b = self.rfile.read(min(left, 1 << 20))
                if not b:
                    break
                f.write(b); left -= len(b)
        if left:
            shutil.rmtree(job.dir, ignore_errors=True)
            return self.reply(400, {"error": "upload incomplete"})
        JOBS[job.id] = job
        job.add(f"received {name} ({n / 1e6:.1f} MB); input {size}x{size}, {'FP16' if q.get('fp16', '1') == '1' else 'FP32'}")
        threading.Thread(target=run_job, args=(job, pt, size, q.get("fp16", "1") == "1", self.server.gpu), daemon=True).start()
        return self.reply(200, {"id": job.id})


def cleanup(hours=24):
    if not os.path.isdir(WORK):
        return
    for d in os.listdir(WORK):
        p = os.path.join(WORK, d)
        if time.time() - os.path.getmtime(p) > hours * 3600:
            shutil.rmtree(p, ignore_errors=True)


def main():
    ap = argparse.ArgumentParser(description="webyolo-agent: Model Export of a YOLOv26 best.pt to ONNX + TensorRT on this PC")
    ap.add_argument("--port", type=int, default=17860)
    ap.add_argument("--allow-origin", action="append", default=[], help="another web origin that may use the agent")
    a = ap.parse_args()
    ORIGINS.update(a.allow_origin)
    os.makedirs(WORK, exist_ok=True)
    cleanup()
    httpd = ThreadingHTTPServer(("127.0.0.1", a.port), Handler)
    httpd.gpu = gpu_info()
    g = httpd.gpu
    print(f"webyolo-agent {__version__} on http://127.0.0.1:{a.port}")
    print(f"  GPU: {g.get('name', '?')} (compute {g.get('compute_capability', '?')}), driver {g.get('driver', '?')}, "
          f"TensorRT {g.get('tensorrt')}, torch {g.get('torch')} (CUDA: {g.get('torch_cuda')})")
    if not g.get("tensorrt"):
        print("  !! TensorRT is not installed: pip install tensorrt")
    print("  Open https://aidevveloper.github.io/webyolov26/export.html  (Ctrl+C stops the agent)", flush=True)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("stopped")


if __name__ == "__main__":
    main()
