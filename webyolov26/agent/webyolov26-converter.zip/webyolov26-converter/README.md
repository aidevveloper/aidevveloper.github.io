# YOLOv26 converter (offline)

Converts a YOLOv26 `best.pt` into:

| File | What it is |
|---|---|
| `best.onnx` | portable model: any PC, server or browser (onnxruntime) |
| `best.engine` | TensorRT engine **built on this PC's GPU** (fastest; runs on this GPU architecture + TensorRT version) |
| `names.json` | class names |
| `info.json` | GPU, versions, and the check against the `.pt` |
| `run.py` | ready detection script: image, folder, video, RTSP, webcam |
| `*.zip` | all of the above in one file |

Both models are checked against the `.pt` on a sample image (same detections, box difference in pixels).
Works with checkpoints trained with the YOLOv26-pt repo (any size n / s / m / l / x, any number of classes).
This is the same converter the web page uses (https://aidevveloper.github.io/webyolov26/convert.html), without the website.

## 1. Requirements

- An NVIDIA GPU with a recent driver (RTX 50 series: driver 570 or newer). Check with `nvidia-smi`.
- Python 3.9 - 3.12.

## 2. Install (once)

Linux:
```bash
cd webyolov26-converter
python -m venv .venv && source .venv/bin/activate            # optional, keeps it separate
pip install torch --index-url https://download.pytorch.org/whl/cu128
pip install -r requirements.txt
```

Windows (PowerShell):
```powershell
cd webyolov26-converter
py -m venv .venv; .venv\Scripts\Activate.ps1                 # optional
py -m pip install torch --index-url https://download.pytorch.org/whl/cu128
py -m pip install -r requirements.txt
```

Check that everything is found:
```bash
python convert.py --info
```
It prints the GPU, compute capability, driver, TensorRT and PyTorch (`CUDA: True` is needed to check the engine and to use `run.py`).

## 3. Convert

```bash
python convert.py --weights path/to/best.pt                 # 640x640, FP16 engine -> ./converted/
python convert.py --weights best.pt --imgsz 960             # another input size (multiple of 32)
python convert.py --weights best.pt --fp32 --out best_fp32  # FP32 engine, other output folder
```

The engine build takes 1-5 minutes. At the end it prints the check, for example:
```
  onnx    pt 10 / model 10, matched 10, box diff 0.0 px, score diff 0.0  -> SAME
  engine  pt 10 / model 10, matched 10, box diff 0.065 px, score diff 0.0006  -> SAME, 0.45 ms
```

## 4. Run the converted model

```bash
cd converted
python run.py --model best.engine --source image.jpg         # image (or a folder of images)
python run.py --model best.engine --source video.mp4 --show  # video with a window (q closes)
python run.py --model best.engine --source rtsp://user:pass@camera-ip/stream
python run.py --model best.engine --source 0                 # webcam
python run.py --model best.onnx   --source image.jpg         # the ONNX, through onnxruntime
```
Results are saved in `runs/<time>/`; every frame is also printed as one JSON line with the detections.

## Model format

- input `images`: float32 `[1, 3, S, S]`, RGB, 0..1, letterbox (scale down only, black border)
- output `output`: float32 `[1, 300, 6]` = x1, y1, x2, y2 (input pixels), score, class id, sorted by score.
  NMS-free: keep the rows with score above your threshold.

## Troubleshooting

| Message | Fix |
|---|---|
| `TensorRT is needed` | `pip install tensorrt` |
| `CUDA: False` | install the CUDA build of torch (the `--index-url .../cu128` line above) |
| `Not a YOLOv26-pt detection model` / `needs code that is not YOLOv26-pt` | the `.pt` comes from another framework; only YOLOv26-pt checkpoints are supported |
| `This engine cannot be loaded here` (run.py) | the engine was built on another GPU or TensorRT version: convert again on this PC, or use the `.onnx` |

## Optional: install as commands

```bash
pip install .
webyolo-convert --weights best.pt      # same as python convert.py
webyolo-agent                          # the local agent for the web page's "Convert here" option
```
