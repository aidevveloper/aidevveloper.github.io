"""python convert.py --weights best.pt   (see README.md)"""
from webyolo_agent.cli import main

main()
