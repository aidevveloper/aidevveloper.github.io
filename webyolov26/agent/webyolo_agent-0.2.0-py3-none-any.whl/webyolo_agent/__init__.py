"""webyolo-agent: converts YOLOv26 best.pt to ONNX and a TensorRT engine for this PC's GPU (used by the webyolov26 page)"""
__version__ = "0.2.0"
