"""best.pt -> best.onnx -> best.engine on this PC's GPU, with a check of both against best.pt.

Supports checkpoints trained with the YOLOv26-pt repo (nets.nn.Detector / YOLO, any size, any number of classes).
The model's eval head goes into the graph, so the outputs are final detections (NMS-free):
    input   images  float32 [1, 3, S, S]  RGB 0..1, letterbox (scale down only, black border)
    output  output  float32 [1, 300, 6]   x1, y1, x2, y2 (input pixels), score, class id; sorted by score
"""
import json
import os
import shutil
import sys
import time
import zipfile

import numpy

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL_CODE = os.path.join(HERE, "models", "yolov26")


class ConvertError(Exception):
    pass


# ---------------------------------------------------------------- pre-processing (same as utils/dataset.py, augment=False)
def letterbox(image_bgr, size):
    import cv2
    h, w = image_bgr.shape[:2]
    r = min(size / h, size / w, 1.0)
    nw, nh = int(round(w * r)), int(round(h * r))
    dw, dh = (size - nw) / 2, (size - nh) / 2
    if (w, h) != (nw, nh):
        image_bgr = cv2.resize(image_bgr, (nw, nh), interpolation=cv2.INTER_LINEAR)
    top, bottom = int(round(dh - 0.1)), int(round(dh + 0.1))
    left, right = int(round(dw - 0.1)), int(round(dw + 0.1))
    image_bgr = cv2.copyMakeBorder(image_bgr, top, bottom, left, right, cv2.BORDER_CONSTANT)
    x = image_bgr.transpose(2, 0, 1)[::-1].astype(numpy.float32) / 255.0  # BGR -> RGB, CHW
    return numpy.ascontiguousarray(x[None]), r, left, top


def compare(ref, out, thr=0.25):
    """ref/out [300, 6]: every detection of ref above thr matched to the nearest same-class box of out"""
    ref, out = ref[ref[:, 4] >= thr], out[out[:, 4] >= thr]
    diffs, sdiffs, matched = [], [], 0
    for r in ref:
        same = out[out[:, 5] == r[5]]
        if not len(same):
            continue
        d = numpy.abs(same[:, :4] - r[:4]).mean(1)
        i = int(d.argmin())
        if d[i] < 8:                                   # same object (pixels)
            matched += 1
            diffs.append(float(d[i])); sdiffs.append(abs(float(same[i, 4] - r[4])))
    return {"ref": int(len(ref)), "out": int(len(out)), "matched": matched,
            "box_px": round(float(numpy.mean(diffs)), 3) if diffs else None,
            "score": round(float(numpy.mean(sdiffs)), 4) if sdiffs else None,
            "ok": bool(len(ref) == len(out) == matched or (matched >= 0.95 * max(len(ref), 1) and abs(len(ref) - len(out)) <= 1))}


# ---------------------------------------------------------------- steps
def load_checkpoint(pt_path, log):
    import torch
    if MODEL_CODE not in sys.path:
        sys.path.insert(0, MODEL_CODE)
    try:
        ckpt = torch.load(pt_path, map_location="cpu", weights_only=False)
    except ModuleNotFoundError as e:
        raise ConvertError(f"This checkpoint needs code that is not YOLOv26-pt ({e.name}). "
                           "Only models trained with the YOLOv26-pt repo are supported.")
    except Exception as e:
        raise ConvertError(f"Cannot read the file as a PyTorch checkpoint: {e}")
    model = ckpt.get("model") if isinstance(ckpt, dict) else ckpt
    if model is None or type(model).__name__ not in ("Detector", "YOLO") or not hasattr(model, "head"):
        raise ConvertError(f"Not a YOLOv26-pt detection model (found {type(model).__name__}).")
    model = model.float().fuse().eval()
    model.head.export = True
    for p in model.parameters():
        p.requires_grad_(False)
    nc = int(model.head.nc)
    names = None
    if isinstance(ckpt, dict) and isinstance(ckpt.get("params"), dict):
        names = ckpt["params"].get("names")
    if isinstance(names, dict):
        names = [str(names.get(i, f"class_{i}")) for i in range(nc)]
    if not names or len(names) != nc:
        names = [f"class_{i}" for i in range(nc)]
    epoch = ckpt.get("epoch") if isinstance(ckpt, dict) else None
    log(f"model: {type(model).__name__}, {nc} classes, {sum(p.numel() for p in model.parameters()) / 1e6:.2f} M parameters"
        + (f", epoch {epoch}" if epoch else ""))
    return model, names


def export_onnx(model, names, size, path, log):
    import torch
    import onnx
    x = torch.zeros(1, 3, size, size)
    with torch.no_grad():
        model(x)
    import warnings
    with warnings.catch_warnings():                     # tracer warnings of the eval head are expected
        warnings.simplefilter("ignore")
        torch.onnx.export(model, x, path, opset_version=17, input_names=["images"], output_names=["output"],
                          do_constant_folding=True, **({"dynamo": False} if "dynamo" in torch.onnx.export.__code__.co_varnames else {}))
    m = onnx.load(path)
    onnx.checker.check_model(m)
    try:
        import onnxsim
        s, ok = onnxsim.simplify(m)
        if ok:
            m = s; log("onnx simplified (onnxsim)")
    except ImportError:
        pass
    except Exception as e:
        log(f"onnxsim skipped: {e}")
    for k, v in (("model", "yolov26"), ("imgsz", str(size)), ("names", json.dumps(names)),
                 ("output", "[1,300,6] x1,y1,x2,y2,score,class (input pixels), NMS-free")):
        p = m.metadata_props.add(); p.key, p.value = k, v
    onnx.save(m, path)
    log(f"onnx saved: {os.path.getsize(path) / 1e6:.1f} MB")


def build_engine(onnx_path, path, size, fp16, log, progress):
    import tensorrt as trt

    class Logger(trt.ILogger):
        def __init__(self):
            trt.ILogger.__init__(self)

        def log(self, severity, msg):
            if severity <= trt.ILogger.Severity.WARNING:
                log(f"[TensorRT] {msg}")

    logger = Logger()
    builder = trt.Builder(logger)
    network = builder.create_network(0)
    parser = trt.OnnxParser(network, logger)
    with open(onnx_path, "rb") as f:
        if not parser.parse(f.read()):
            raise ConvertError("TensorRT cannot parse the ONNX: " + "; ".join(str(parser.get_error(i)) for i in range(parser.num_errors)))
    config = builder.create_builder_config()
    config.set_memory_pool_limit(trt.MemoryPoolType.WORKSPACE, 4 << 30)
    if fp16:
        config.set_flag(trt.BuilderFlag.FP16)
    if hasattr(trt, "IProgressMonitor"):                 # TensorRT >= 10: build progress for the web page
        class Monitor(trt.IProgressMonitor):
            def __init__(self):
                trt.IProgressMonitor.__init__(self)
                self.steps = {}

            def phase_start(self, phase_name, parent_phase, num_steps):
                self.steps[phase_name] = (parent_phase, num_steps)

            def step_complete(self, phase_name, step):
                parent, n = self.steps.get(phase_name, (None, 0))
                if parent is None and n:
                    progress(0.45 + 0.45 * (step + 1) / n)
                return True

            def phase_finish(self, phase_name):
                pass

        config.progress_monitor = Monitor()
    t = time.time()
    data = builder.build_serialized_network(network, config)
    if data is None:
        raise ConvertError("TensorRT engine build failed (see the log).")
    with open(path, "wb") as f:
        f.write(data)
    log(f"engine saved: {os.path.getsize(path) / 1e6:.1f} MB, built in {time.time() - t:.0f} s")


def run_engine(path, x):
    import tensorrt as trt
    import torch
    engine = trt.Runtime(trt.Logger(trt.Logger.ERROR)).deserialize_cuda_engine(open(path, "rb").read())
    ctx = engine.create_execution_context()
    names = [engine.get_tensor_name(i) for i in range(engine.num_io_tensors)]
    inp = next(n for n in names if engine.get_tensor_mode(n) == trt.TensorIOMode.INPUT)
    out = next(n for n in names if engine.get_tensor_mode(n) == trt.TensorIOMode.OUTPUT)
    xi = torch.from_numpy(x).cuda()
    y = torch.empty(tuple(ctx.get_tensor_shape(out)), dtype=torch.float32, device="cuda")
    ctx.set_tensor_address(inp, xi.data_ptr()); ctx.set_tensor_address(out, y.data_ptr())
    s = torch.cuda.Stream()
    torch.cuda.synchronize()
    ctx.execute_async_v3(s.cuda_stream); s.synchronize()
    t = time.perf_counter()
    for _ in range(50):
        ctx.execute_async_v3(s.cuda_stream)
    s.synchronize()
    return y[0].cpu().numpy(), (time.perf_counter() - t) / 50 * 1000


# ---------------------------------------------------------------- the whole job
def convert(pt_path, out_dir, size=640, fp16=True, log=print, progress=lambda p: None, gpu=None):
    import cv2
    import torch
    os.makedirs(out_dir, exist_ok=True)
    stem = os.path.splitext(os.path.basename(pt_path))[0] or "best"
    onnx_path, engine_path = os.path.join(out_dir, stem + ".onnx"), os.path.join(out_dir, stem + ".engine")
    result = {"files": [], "verify": {}}

    progress(0.02); log("loading the checkpoint")
    model, names = load_checkpoint(pt_path, log)
    x, *_ = letterbox(cv2.imread(os.path.join(HERE, "sample.jpg")), size)
    with torch.no_grad():
        ref = model(torch.from_numpy(x))[0].numpy()     # FP32 reference on the CPU

    progress(0.10); log(f"exporting ONNX ({size}x{size}, opset 17)")
    export_onnx(model, names, size, onnx_path, log)
    try:
        import onnxruntime as ort
        y = ort.InferenceSession(onnx_path, providers=["CPUExecutionProvider"]).run(None, {"images": x})[0][0]
        result["verify"]["onnx"] = compare(ref, y)
        log(f"check onnx vs pt: {result['verify']['onnx']}")
    except ImportError:
        log("onnxruntime not installed: ONNX check skipped")

    progress(0.40); log(f"building the TensorRT engine ({'FP16' if fp16 else 'FP32'}) on this GPU, takes 1-5 min")
    build_engine(onnx_path, engine_path, size, fp16, log, progress)
    progress(0.92)
    if torch.cuda.is_available():
        y, ms = run_engine(engine_path, x)
        result["verify"]["engine"] = compare(ref, y)
        result["verify"]["engine"]["ms"] = round(ms, 2)
        log(f"check engine vs pt: {result['verify']['engine']}")
    else:
        log("PyTorch has no CUDA here: engine check skipped (install the CUDA build of torch to check and to use run.py)")

    import tensorrt as trt
    info = {"model": "yolov26", "source": os.path.basename(pt_path), "imgsz": size, "precision": "fp16" if fp16 else "fp32",
            "classes": len(names), "tensorrt": trt.__version__, "torch": torch.__version__, "gpu": gpu or {},
            "created": time.strftime("%Y-%m-%d %H:%M:%S"), "verify": result["verify"],
            "input": "images [1,3,S,S] RGB 0..1 letterbox", "output": "output [1,300,6] x1,y1,x2,y2,score,class"}
    with open(os.path.join(out_dir, "names.json"), "w") as f:
        json.dump(names, f, indent=1, ensure_ascii=False)
    with open(os.path.join(out_dir, "info.json"), "w") as f:
        json.dump(info, f, indent=1, ensure_ascii=False)
    shutil.copy(os.path.join(HERE, "run_template.py"), os.path.join(out_dir, "run.py"))
    g = (gpu or {}).get("name", "this GPU")
    with open(os.path.join(out_dir, "README.txt"), "w") as f:
        f.write(f"""{stem}: YOLOv26 model converted by webyolo-agent

{stem}.engine  TensorRT {trt.__version__}, {info['precision'].upper()}, built on {g}.
               Runs only on the same GPU architecture with the same TensorRT version.
{stem}.onnx    portable: any PC / server / browser (onnxruntime)
names.json     class names ({len(names)})
info.json      conversion details and the check against the .pt
run.py         ready-to-use detection script

Run (needs: pip install tensorrt opencv-python numpy torch  -- the CUDA build of torch):
  python run.py --model {stem}.engine --source image.jpg            # image, folder, video, rtsp://..., or 0 (webcam)
  python run.py --model {stem}.engine --source video.mp4 --show
  python run.py --model {stem}.onnx --source image.jpg               # ONNX through onnxruntime
Output: drawn images / video in runs/ and one JSON line per frame with the detections.
""")
    files = [f"{stem}.onnx", f"{stem}.engine", "names.json", "info.json", "run.py", "README.txt"]
    zname = f"{stem}_{''.join(c for c in g.replace('NVIDIA ', '').replace('GeForce ', '') if c.isalnum())}_trt{'.'.join(trt.__version__.split('.')[:2])}_{info['precision']}.zip"
    with zipfile.ZipFile(os.path.join(out_dir, zname), "w", zipfile.ZIP_DEFLATED) as z:
        for fn in files:
            z.write(os.path.join(out_dir, fn), fn)
    result["files"] = files + [zname]
    result["info"] = info
    progress(1.0); log("done")
    return result
