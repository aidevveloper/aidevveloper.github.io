"""run.py - YOLOv26 detection with the converted model (TensorRT .engine or .onnx). Made by webyolo-agent.

    python run.py --model best.engine --source image.jpg
    python run.py --model best.engine --source images/            # every image in a folder
    python run.py --model best.engine --source video.mp4 --show   # window with the boxes (q closes)
    python run.py --model best.engine --source rtsp://user:pass@ip/stream
    python run.py --model best.engine --source 0                  # webcam 0
    python run.py --model best.onnx   --source image.jpg          # ONNX through onnxruntime (GPU if onnxruntime-gpu)

Needs: numpy, opencv-python; for .engine: tensorrt + torch with CUDA; for .onnx: onnxruntime.
Saves drawn results to runs/<time>/ (use --no-save to skip) and prints one JSON line per frame:
    {"frame": 0, "source": "...", "ms": 1.2, "dets": [[x1, y1, x2, y2, score, class_id, "name"], ...]}
"""
import argparse
import glob
import json
import os
import time

import cv2
import numpy

IMAGES = (".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tif", ".tiff")


class Model:
    def __init__(self, path):
        self.path = path
        if path.endswith(".engine"):
            import tensorrt as trt
            import torch
            if not torch.cuda.is_available():
                raise SystemExit("A .engine needs PyTorch with CUDA (pip install torch --index-url https://download.pytorch.org/whl/cu128)")
            self.torch = torch
            with open(path, "rb") as f:
                self.engine = trt.Runtime(trt.Logger(trt.Logger.WARNING)).deserialize_cuda_engine(f.read())
            if self.engine is None:
                raise SystemExit("This engine cannot be loaded here: it was built for another GPU or TensorRT version. "
                                 "Use the .onnx, or convert again on this PC.")
            self.ctx = self.engine.create_execution_context()
            names = [self.engine.get_tensor_name(i) for i in range(self.engine.num_io_tensors)]
            self.inp = next(n for n in names if self.engine.get_tensor_mode(n) == trt.TensorIOMode.INPUT)
            self.out = next(n for n in names if self.engine.get_tensor_mode(n) == trt.TensorIOMode.OUTPUT)
            self.size = int(self.engine.get_tensor_shape(self.inp)[-1])
            self.y = torch.empty(tuple(self.ctx.get_tensor_shape(self.out)), dtype=torch.float32, device="cuda")
            self.stream = torch.cuda.Stream()
        else:
            import onnxruntime as ort
            prov = [p for p in ("CUDAExecutionProvider", "CPUExecutionProvider") if p in ort.get_available_providers()]
            self.sess = ort.InferenceSession(path, providers=prov)
            self.size = int(self.sess.get_inputs()[0].shape[-1])
            self.meta = self.sess.get_modelmeta().custom_metadata_map

    def __call__(self, x):
        if hasattr(self, "engine"):
            xi = self.torch.from_numpy(x).cuda()
            self.ctx.set_tensor_address(self.inp, xi.data_ptr())
            self.ctx.set_tensor_address(self.out, self.y.data_ptr())
            self.torch.cuda.current_stream().synchronize()
            self.ctx.execute_async_v3(self.stream.cuda_stream)
            self.stream.synchronize()
            return self.y[0].cpu().numpy()
        return self.sess.run(None, {self.sess.get_inputs()[0].name: x})[0][0]


def letterbox(image, size):
    """same as the training repo's test: scale down only, black border, RGB, 0..1"""
    h, w = image.shape[:2]
    r = min(size / h, size / w, 1.0)
    nw, nh = int(round(w * r)), int(round(h * r))
    dw, dh = (size - nw) / 2, (size - nh) / 2
    if (w, h) != (nw, nh):
        image = cv2.resize(image, (nw, nh), interpolation=cv2.INTER_LINEAR)
    top, bottom = int(round(dh - 0.1)), int(round(dh + 0.1))
    left, right = int(round(dw - 0.1)), int(round(dw + 0.1))
    image = cv2.copyMakeBorder(image, top, bottom, left, right, cv2.BORDER_CONSTANT)
    x = image.transpose(2, 0, 1)[::-1].astype(numpy.float32) / 255.0
    return numpy.ascontiguousarray(x[None]), r, left, top


def detect(model, frame, conf):
    x, r, left, top = letterbox(frame, model.size)
    t = time.perf_counter()
    y = model(x)
    ms = (time.perf_counter() - t) * 1000
    y = y[y[:, 4] >= conf].copy()
    h, w = frame.shape[:2]
    y[:, [0, 2]] = ((y[:, [0, 2]] - left) / r).clip(0, w)
    y[:, [1, 3]] = ((y[:, [1, 3]] - top) / r).clip(0, h)
    return y, ms


def color(c):
    p = [(75, 25, 230), (75, 180, 60), (216, 99, 67), (49, 130, 245), (180, 30, 145), (177, 163, 15), (230, 50, 240),
         (24, 181, 124), (23, 160, 212), (128, 128, 0), (36, 99, 154), (0, 0, 128), (68, 158, 47), (0, 128, 128)]
    return p[int(c) % len(p)]


def draw(frame, dets, names):
    lw = max(2, round(max(frame.shape[:2]) / 400))
    for x1, y1, x2, y2, s, c in dets:
        col = color(c)
        cv2.rectangle(frame, (int(x1), int(y1)), (int(x2), int(y2)), col, lw)
        label = f"{names[int(c)] if int(c) < len(names) else int(c)} {s:.2f}"
        (tw, th), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
        ty = int(y1) - th - 6 if y1 - th - 6 > 0 else int(y1)
        cv2.rectangle(frame, (int(x1), ty), (int(x1) + tw + 6, ty + th + 6), col, -1)
        cv2.putText(frame, label, (int(x1) + 3, ty + th + 2), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1, cv2.LINE_AA)
    return frame


def main():
    ap = argparse.ArgumentParser(description="YOLOv26 detection with a converted model")
    ap.add_argument("--model", default="best.engine")
    ap.add_argument("--source", required=True, help="image, folder, video, rtsp:// url, or a webcam number")
    ap.add_argument("--conf", type=float, default=0.25)
    ap.add_argument("--names", default=None, help="names.json (default: next to the model)")
    ap.add_argument("--show", action="store_true")
    ap.add_argument("--no-save", action="store_true")
    a = ap.parse_args()

    model = Model(a.model)
    npath = a.names or os.path.join(os.path.dirname(os.path.abspath(a.model)), "names.json")
    names = json.load(open(npath)) if os.path.exists(npath) else json.loads(getattr(model, "meta", {}).get("names", "[]"))
    out = None if a.no_save else os.path.join("runs", time.strftime("%Y%m%d-%H%M%S"))
    if out:
        os.makedirs(out, exist_ok=True)

    def emit(i, src, frame, dets, ms):
        print(json.dumps({"frame": i, "source": src, "ms": round(ms, 2),
                          "dets": [[round(float(v), 1) for v in d[:4]] + [round(float(d[4]), 3), int(d[5]),
                                   names[int(d[5])] if int(d[5]) < len(names) else str(int(d[5]))] for d in dets]}), flush=True)

    s = a.source
    files = sorted(f for f in glob.glob(os.path.join(s, "*")) if f.lower().endswith(IMAGES)) if os.path.isdir(s) else \
        [s] if s.lower().endswith(IMAGES) else None
    if files is not None:                                       # images
        for i, f in enumerate(files):
            frame = cv2.imread(f)
            if frame is None:
                print(f"cannot read {f}"); continue
            dets, ms = detect(model, frame, a.conf)
            emit(i, f, frame, dets, ms)
            vis = draw(frame, dets, names)
            if out:
                cv2.imwrite(os.path.join(out, os.path.basename(f)), vis)
            if a.show:
                cv2.imshow("YOLOv26", vis)
                if cv2.waitKey(0) & 0xFF == ord("q"):
                    break
    else:                                                       # video / stream / webcam
        cap = cv2.VideoCapture(int(s) if s.isdigit() else s)
        if not cap.isOpened():
            raise SystemExit(f"cannot open {s}")
        writer, i = None, 0
        while True:
            ok, frame = cap.read()
            if not ok:
                break
            dets, ms = detect(model, frame, a.conf)
            emit(i, s, frame, dets, ms)
            vis = draw(frame, dets, names)
            if out:
                if writer is None:
                    fps = cap.get(cv2.CAP_PROP_FPS) or 25
                    writer = cv2.VideoWriter(os.path.join(out, "result.mp4"), cv2.VideoWriter_fourcc(*"mp4v"), fps,
                                             (vis.shape[1], vis.shape[0]))
                writer.write(vis)
            if a.show:
                cv2.imshow("YOLOv26", vis)
                if cv2.waitKey(1) & 0xFF == ord("q"):
                    break
            i += 1
        cap.release()
        if writer:
            writer.release()
    if a.show:
        cv2.destroyAllWindows()
    if out:
        print(f"saved to {out}")


if __name__ == "__main__":
    main()
